/* Database export results for db reserva vehiculos */

/* Preserve session variables */
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS;
SET FOREIGN_KEY_CHECKS=0;

/* Export data */

/* Table structure for empleados */
CREATE TABLE `empleados` (
  `idempleado` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` tinytext,
  `apellidos` tinytext,
  `salario` int(11) DEFAULT NULL,
  `idoficina` int(11) DEFAULT NULL,
  PRIMARY KEY (`idempleado`)
) ENGINE=InnoDB AUTO_INCREMENT=8766 DEFAULT CHARSET=latin1;

/* data for Table empleados */
INSERT INTO `empleados` VALUES (2534,"sergio","leon",20000,21);
INSERT INTO `empleados` VALUES (5643,"maria","perez",22000,22);
INSERT INTO `empleados` VALUES (5688,"antonio","novalio",21000,22);
INSERT INTO `empleados` VALUES (7243,"raul","moreno",21000,23);
INSERT INTO `empleados` VALUES (8765,"francisco","mora",20000,21);

/* Table structure for reservas */
CREATE TABLE `reservas` (
  `idreserva` int(11) NOT NULL AUTO_INCREMENT,
  `idvehiculos` int(11) DEFAULT NULL,
  `destino` tinytext,
  `kilometros` int(11) DEFAULT NULL,
  `idempleado` int(11) DEFAULT NULL,
  PRIMARY KEY (`idreserva`)
) ENGINE=InnoDB AUTO_INCREMENT=9565 DEFAULT CHARSET=latin1;

/* data for Table reservas */
INSERT INTO `reservas` VALUES (2976,222,"sevilla",60,5688);
INSERT INTO `reservas` VALUES (8111,124,"sevilla",60,5688);
INSERT INTO `reservas` VALUES (8222,243,"jaen",600,7243);
INSERT INTO `reservas` VALUES (8423,111,"huelva",100,8765);
INSERT INTO `reservas` VALUES (9564,934,"malaga",350,5643);

/* Table structure for vehiculos */
CREATE TABLE `vehiculos` (
  `idvehiculos` int(11) NOT NULL AUTO_INCREMENT,
  `modelo` tinytext,
  `color` tinytext,
  `matricula` int(11) DEFAULT NULL,
  `kilometros` int(11) DEFAULT NULL,
  PRIMARY KEY (`idvehiculos`)
) ENGINE=InnoDB AUTO_INCREMENT=935 DEFAULT CHARSET=latin1;

/* data for Table vehiculos */
INSERT INTO `vehiculos` VALUES (111,"seat","blanco",1253,25000);
INSERT INTO `vehiculos` VALUES (124,"opel","rojo",8321,23000);
INSERT INTO `vehiculos` VALUES (222,"mercedes","negro",9822,28000);
INSERT INTO `vehiculos` VALUES (243,"skoda","blanco",7654,76000);
INSERT INTO `vehiculos` VALUES (934,"citroen","gris",5345,20000);

/* Restore session variables to original values */
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
